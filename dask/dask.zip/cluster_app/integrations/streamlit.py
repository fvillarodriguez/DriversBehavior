from __future__ import annotations

from typing import Any

from cluster_app.sdk import DaskCluster


def render_cluster_panel(cluster: DaskCluster | None = None, key: str = "dask_cluster") -> DaskCluster:
    try:
        import streamlit as st
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "streamlit is required to render the Dask cluster panel. "
            "Install streamlit in the ML app environment."
        ) from exc

    if cluster is None:
        if key not in st.session_state:
            st.session_state[key] = DaskCluster()
        cluster = st.session_state[key]

    status = cluster.status()
    scheduler = _as_mapping(status.get("scheduler"))
    worker = _as_mapping(status.get("worker"))
    nodes = status.get("nodes") or []

    st.subheader("Dask Cluster")
    scheduler_col, worker_col, nodes_col = st.columns(3)
    scheduler_col.metric("Scheduler", "running" if scheduler.get("running") else "stopped")
    worker_col.metric("Worker", "running" if worker.get("running") else "stopped")
    nodes_col.metric("Nodes", str(len(nodes)))

    action_col, refresh_col = st.columns(2)
    if action_col.button("Start", key=f"{key}_start", disabled=bool(status.get("started"))):
        cluster.start()
        st.rerun()
    if action_col.button("Stop", key=f"{key}_stop", disabled=not bool(status.get("started"))):
        cluster.stop()
        st.rerun()
    if refresh_col.button("Refresh", key=f"{key}_refresh"):
        st.rerun()

    dashboard = status.get("dashboard")
    if dashboard:
        st.link_button("Open Dask Dashboard", str(dashboard))
    if scheduler.get("address"):
        st.caption(f"Scheduler: {scheduler['address']}")
    return cluster


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}
